/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package personalfinancemanager;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author marcusmaibach
 */


public class Main extends Application {
    protected static DAO dao = new DAO();
    
    public static void main(String[] args) {
        dao.connect();
        dao.closeDB();
        Application.launch(Main.class, (java.lang.String[])null);
        
    }

    @Override
    public void start(Stage primaryStage) {
        try {
            //*
            FXMLLoader loader = new FXMLLoader(getClass().getResource("MainMenu.fxml"));
            Scene scene = new Scene(loader.load(), 480, 320);
            //  ^ THIS IS WHERE I INJECT LOGIN FXML */
            
            
            primaryStage.setTitle("Personal Finance Manager");
            primaryStage.setScene(scene);
            primaryStage.show();
            
        } catch (IOException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }   
    }
}
